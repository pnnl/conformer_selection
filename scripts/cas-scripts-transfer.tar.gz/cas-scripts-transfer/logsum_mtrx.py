import pandas as pd
import numpy as np
import glob
from math import log
from time import time

# Automatically grab molecule ID and adduct type
paths = glob.glob('output/dft/*')
for p in paths:
    if 'benchmarks' not in p and 'logs' not in p and '.py' not in p and 'bkp' not in p:
        id_add = p.split('/')[-1]
print(id_add)


df = pd.read_pickle(f'pwRMSD/{id_add}_50k_50k_reflect.pkl')

## Replace 0's with large number so we can take the minimum pwRMSD
#df.replace(0.0,500.0)
print(df)
df = df.replace(0.0, np.nan)
print(df)
df.to_pickle(f'pwRMSD/{id_add}_50k_50k_reflect_logsum.pkl')

#min_rmsd = df.min().min()
#print('minimum RMSD', min_rmsd)
#print('log minimum RMSD', log(min_rmsd))
#print('factor 1/10', log(min_rmsd/10))
#print('factor 1/100', log(min_rmsd/100))
