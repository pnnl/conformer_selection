"""Uses Monte Carlo methods to find the subset of n most dissimliar molecular
    geometries (conformers). Uses pairwise RMSDs for each geometry as calculated
    by pwrmsd_writer.py (or pairwise RMSD writer.ipynb)
"""

from time import time
from itertools import combinations
import numpy as np
import pandas as pd
from os.path import *
from numpy import random
import argparse
import os
import glob
from statsmodels.stats.weightstats import DescrStatsW
from math import log

def df_concat(ID, ADD, max_cycle=1000, reflect=True):
    """Merges all per cycle dataframes of pairwise rmsds into one dataframe.
    Args:
        reflect (bool): Reflects matrix across diagonal (columns become rows starting from the top).
                        Loads from .pkl if already exists, saves if doesn't.
    """
    if reflect == True:
        if os.path.exists(f'pwRMSD/{ID}_{ADD}_50k_50k_reflect.pkl'):
            print('Loading symmetric matrix...')
            df = pd.read_pickle(f'pwRMSD/{ID}_{ADD}_50k_50k_reflect.pkl')
            return df
        else:
            print('No matrix found.')
            pass

    print('Concatenating...')
    df = pd.DataFrame()
    cycles = ['%04d' % x for x in range(1, max_cycle+1)]
    for cyc in cycles:
        piecedf = pd.read_pickle(abspath('pwRMSD/{}_{}_cycle{}_pwrmsd.pkl'.format(ID, ADD, cyc)))
        df = df.append(piecedf, ignore_index=True)
        
    if reflect == True:
        for i in range(len(df.columns)):
            df[i] = df.loc[i]
        df.to_pickle(f'pwRMSD/{ID}_{ADD}_50k_50k_reflect.pkl')

    return df


def df_dissect(ID, ADD, cycle, gnum=50, reflect=True):
    """Pulls out the square matrix of pairwise rmsds belonging only to the specified cycle.
        Returns as pandas dataframe.
    Args:
        ID (string): molecular identifier, e.g. the inchi key 'BXNJHAXVSOCGBA-UHFFFAOYSA-N'
        ADD (string): adduct, e.g. '+H'
        cycle (string): Cycle to be considered, formated as it would appear in its file path,
                        e.g. '0001' for cycle 1
        gnum (int): Number of geometries per cycle. Default 50.
    """
    df = pd.read_pickle(abspath('pwRMSD/{}_{}_cycle{}_pwrmsd.pkl'.format(ID, ADD, cycle)))
    cycle = int(cycle)
    begin = (cycle - 1)*gnum
    end = cycle*gnum
    df2 = df[df.columns[begin:end]]
    df2.columns = [x for x in range(0, gnum)]

    if reflect == True:
        for i in range(len(df2.columns)):
            df2[i] = df2.loc[i]

    return df2


def bycycle(ID, ADD, n=3, method='heuristic', tot_cyc=1000, tot_geom=50, mxset=100, itr=10000, period=3600):
    """
    """
    print('Evaluating by cycle...')
    df_all = pd.DataFrame()
    for cycle in range(1, tot_cyc+1):
        cycle_str = '%04d' % cycle
        df = df_dissect(ID, ADD, cycle_str, gnum=tot_geom)
        if method == 'heuristic':
            df_all = df_all.append(heuristic_most_dissim_set(df, n=n))
        elif method == 'mc':
            # Set time limit so all cycles combined run at most (about*) an hour 
              #(*inevitable spill over because of where the time-limit checks are located in the program)
            timestop = period/tot_cyc
            dfMC = MC_most_dissim_set(df, n=n, max_set_size=mxset, itr=itr, PERIOD_OF_TIME=timestop)

            # Take only the last line, which correpsonds to the largest MC set
            df_all = df_all.append(dfMC.loc[len(dfMC)-1])
        else:
            print('Error, {} not a valid method. Use either \'heuristic\', or \'mc\' '.format(method))
            break

    # Re-index rows according to cycle
    df_all.index = [x for x in range(1, tot_cyc+1)]
    return df_all

def MC_most_dissim_set(df, n=3, max_set_size=100, itr=10000, PERIOD_OF_TIME=3600):
    """Finds the most dissimilar set of size n using Monte Carlo (MC) simulation.  
    Args:
      df (pandas.DataFrame): contains pairwise rmsd matrix where each row and colum correponds to a conformation.
      n (int): Conformer set size for comparing dissimilarity, i.e. the n most dissimilar geometries
      max_set_size (int): Max MC set size (not to be confused with n)
      itr (int): Number of MC iterations per `max_set_size`.
      PERIOD_OF_TIME (int): Given in seconds, default 3600 sec (1 hour).
                            Only allow the simulation to run for this prescribed amount of time, regardless
                            of max set size or iteration count. 
    Returns:
      pandas.DataFrame of average, standard deviation, maximum, and the corresponding maxiumum n geometries
        of the MC simulation. 
    """
    start = time()

    # Check df matrix is square
    N = len(df.index)
    assert N == len(df.columns)
    if N == 50000:
        print('Starting Monte Carlo simulation...')
    
    random.seed()
    return_df = pd.DataFrame() # Initialize dataframe

    for i in range(1, max_set_size+1):
        start_sets = time()
        rmsd = []
        mx_indices = []

        for j in range(itr):
            sums = [] #figure out how to append to numpy array, then change these all to numpy.array()
            indices = []

            for k in range(i):
                ind = random.choice(range(N), n, replace=False)
                indices.append(ind) # Keep for later reference. Indices and sums match one-to-one.
                pairs = combinations(ind, 2) # Include all pairs
                sm = 0

                for p in pairs:
                    sm += df.loc[min(p)][max(p)]
                sums.append(sm)

            sums = np.array(sums) # Reduce number of times sums converts to np.array()
            rmsd.append(np.max(sums)) 
            mx_indices.append(indices[np.argmax(sums)])

        # Average over the `itr` number of iterations
        rmsd = np.array(rmsd) # Reduce number of times rmsd converts to np.array()
        rmsd_ave = np.mean(rmsd)
        rmsd_std = np.std(rmsd)

        # Find the most dissimilar set
        mx_pwrmsd_sum = np.max(rmsd)
        most_dism_set = mx_indices[np.argmax(rmsd)]
        
        # Append to a dataframe
        intermdf = pd.DataFrame([rmsd_ave, rmsd_std, mx_pwrmsd_sum, np.sort(most_dism_set)]).T
        return_df = return_df.append(intermdf, ignore_index=True)

        time_sets = (time() - start_sets)/60.0
        print(f'set size {i} finished at {time_sets} min')

        # Exit if simulation runs longer than prescribed time
        if time() > start + PERIOD_OF_TIME:
            return_df.columns = ['Ave', 'Stdev', 'Max', 'Conformers']
            print(f'Exceeded time limit of {PERIOD_OF_TIME} seconds')
            return(return_df)
        
    return_df.columns = ['Ave', 'Stdev', 'Max', 'Conformers']
    print('Finished')
    return return_df


def bw_ccs(df):
    """Modified from ISiCLE
    """

    g = df['dft_energy'].values * 627.503
    mn = g.min()
    relG = g - mn
    b = np.exp(-relG / 0.5924847535)
    w = (b / b.sum()) * len(b)

    ws = DescrStatsW(df['ccs'], weights=w, ddof=0)

    #res = pd.DataFrame([[ws.mean, ws.std]],
    #                   columns=['ccs', 'ccs_std'])

    #res.to_csv(outfile, sep='\t', index=False, header=True)
    return ws.mean


def heuristic_most_dissim_set(df, n=3):
    """Finds the most dissimilar set of size n using Monte Carlo (MC) simulation.  
    Args:
      df (pandas.DataFrame): contains pairwise rmsd matrix where each row and colum correponds to a conformation.
      n (int): Conformer set size for comparing dissimilarity, i.e. the n most dissimilar geometries
    Returns:
      pandas.DataFrame of average, standard deviation, maximum, and the corresponding maxiumum n geometries
        of the heuristic simulation. 
    """
    # Check df matrix is square
    N = len(df.index)
    assert N == len(df.columns)
    
#    # Reduce n to maximum number of conformers if n is over, otherwise simulation will fail.
#    M = len(df.dropna(how='all'))
#    if n > M:
#        n = M

    print(f'Starting iterative simulation with n = {n}...')

    # First grab matrix indices of the two most dissimilar geometries
    row_mx = []
    
    for i in range(N):
        row_mx.append(np.nanmax(df.loc[i]))
    ind1 = np.nanargmax(row_mx)
    ind2 = ind1 + 1 + np.nanargmax(row_mx[ind1+1:])

    # Initialize dissimilar RMSD-array with the two most dissimilar geometries
    disarray = [np.array(df.loc[ind1]), np.array(df.loc[ind2])]
    indices = [ind1, ind2]
    
    # Find n other most dissimilar arrays by multiplying the previously found geometries
      # RMSD arrays and taking the index of the largest value

    ## Initialize multiplication array
    #mult = [1 for x in range(N)] #Because square N = len(disarray[i])
    #mult *= disarray[0]

    # Initialize array for log summing
    logsum = [0 for x in range(N)]
    logsum += np.log(disarray[0])
    
    #for i in range(2, n):
    for i in range(n-2):
        logsum += np.log(disarray[-1])
        indn = np.nanargmax(logsum)
        indices.append(indn)
        disarray.append(np.array(df.loc[indn]))

        ## Normalize mult array so it doesn't exceed machine precision
        #mult /= np.max(mult)
      
    return_df = pd.DataFrame([[indices]], columns=['Conformers']) 
    print('Finished')
    return return_df   


def conf_to_ccs(conformers, ID, ADD, narray=None):
    """Converts list of conformer indexes (from a 50x50 matrix) to Boltzmann weighted CCS average and Lowest Energy CCS.
    Args:
      conformers (np.array): Array of conformer indexes selected from a 50x50 rmsd matrix as returned in the 
                             heuristic_most_dissim_set() dataframe.
      ID (str): molecule name or identifier, e.g. the inchi key
      ADD (str): adduct type, e.g. '+H'

    Returns:
      df with new columns: DFT Energy, CCS, BW CCS, and Lowest Energy CCS
    """
    print('Calculating CCSs...')
    
    # Convert indices to cycle and geometry
    conformers = np.array(conformers)
    g = conformers % 50 + 1
    c = np.floor(conformers / 50).astype(int) + 1

    # Find files and grab energy and CCS
    tsv_str = f'output/mobility/mobcal/conformer_ccs/{ID}_{ADD}_%04d_geom%02d.tsv' #BXNJHAXVSOCGBA-UHFFFAOYSA-N_+H_0001_geom04.tsv
    tsvdf = pd.DataFrame()

    index = []
    for i in range(len(c)):
        readf = pd.read_csv(tsv_str % (c[i], g[i]), delimiter='\t')
        tsvdf = tsvdf.append(readf, ignore_index=True)
        index.append(i+1)
    tsvdf.index = index

    columns = ['n Dissimilar', 'Conformer', 'CCS', 'DFT Energy', 'BW CCS', 'Lowest Energy CCS']
    finaldf = pd.DataFrame(columns=columns)
    if narray is None:
        narray = np.array([len(conformers)])

    for n in narray:
        # Calculate Boltzmann Weighted CCS
        bw =  bw_ccs(tsvdf.loc[1:n])

        # Find CCS with the lowest energy
        idx = tsvdf.loc[1:n]['dft_energy'].idxmin()
        lec = tsvdf['ccs'][idx]
        finaldf = finaldf.append(pd.DataFrame([[n,conformers[n-1], tsvdf['ccs'][n], tsvdf['dft_energy'][n], bw, lec]],
                                              columns=columns), ignore_index=True)

    return finaldf


if __name__ == '__main__':
    start = time()
    
    parser = argparse.ArgumentParser()
    parser.add_argument('-b', '--bycycle', type=bool, default=False, 
                        help='If true, does MC or heuristic by cycle, instead of all as one')
    parser.add_argument('-m', '--method', type=str, default='heuristic', 
                        help='Either Monte Carlo, \'mc\' or iterative, \'heurisitic\'')
    parser.add_argument('-c', '--cycles', type=int, default=1000,
                        help='total number of cycles')
    parser.add_argument('-g', '--geoms', type=int, default=50, 
                        help='total number of geometries per cycle')
    parser.add_argument('-i', '--itr', type=int, default=10000,
                        help='number of MC iterations')
    parser.add_argument('-n', '--ndis', type=int, default=3, 
                        help='find the n most dissimilar conformers (geometries)')
    parser.add_argument('-p', '--period', type=float, default=3600,
                        help='Given in seconds, only allow MC simulation to run this long.')
    
    args = parser.parse_args()    
    n = args.ndis
    method = args.method

    # If NDisConf is not already a directory, make it
    directory = 'NDisConf'
    if not os.path.exists(directory):
        os.makedirs(directory)

    # Automatically grab molecule ID and adduct type
    paths = glob.glob('output/dft/*')
    for p in paths:
        if 'benchmarks' not in p and 'logs' not in p and '.py' not in p and 'bkp' not in p:
            id_add = p.split('/')[-1]
    idadd = id_add.split('_')
    ID = idadd[0]
    ADD = idadd[1]
    print(ID, ADD)


    if args.bycycle == True:
        writedf = bycycle(ID, ADD, n=n, method=method, tot_geom=args.geoms, tot_cyc=args.cycles, 
                          mxset=args.mxset, itr=args.itr, period=args.period)
        writedf.to_csv('{}_{}_{}_{}_dissm_by_cycle.csv'.format(ID, ADD, args.method, n), index=False)
        print((time()-start)/60, 'min')

    else:
        #df = df_concat(ID, ADD, max_cycle=args.cycles)
        df = pd.read_pickle(f'pwRMSD/{ID}_{ADD}_50k_50k_reflect_logsum.pkl')
        # Reduce n to maximum number of conformers if n is over, otherwise simulation will fail.     
        M = len(df.dropna(how='all'))
        if n > M:
            n = M
        if method == 'heuristic':
            intermdf = heuristic_most_dissim_set(df, n=n)
            narray = np.array([x for x in range(1, n+1)])
            writedf = conf_to_ccs(intermdf['Conformers'][0], ID, ADD, narray=narray)
        elif method == 'mc':
            print('v2 not yet modified to handle MC. See original version of the script.')
        #    writedf = MC_most_dissim_set(df, n=n, max_set_size=args.mxset, itr=args.itr, PERIOD_OF_TIME=args.period)
        else:
            print(f'Error, {method} not a valid method. Use either \'heuristic\', or \'mc\' ')

        writedf['n Dissimilar'] = narray
        writedf.to_csv(f'NDisConf/{ID}_{ADD}_{method}_{1}to{n}_dissm_logsum.csv', index=False)
        print((time()-start)/60, 'min')
        
        
