from rdkit import Chem
from rdkit.Chem import AllChem
from os.path import abspath, join, exists
from os import makedirs
import pybel
from time import time

if __name__ == '__main__':
    START = time()

    smi = '[OH2+][C@@H](C#N)C1=CC=CC=C1'
    id_add = 'NNICRUQPODTGRU-SVGMAFHSNA-N_+H'
    m = Chem.MolFromSmiles(smi)
    m2 = Chem.AddHs(m) # Maybe I should explicitly add my own H and then skip this step? No, doesn't work because it then removes the hydrogens for some reason...
    cnm = 1000
    gnm = 50

    # Make output and mol directory
    dirmol = 'output/mol'
    if not exists(dirmol):
        makedirs(dirmol)

    ids = list(AllChem.EmbedMultipleConfs(m2, numConfs=cnm*gnm)) #, randomSeed=r))
    #for d in ids:
    #    AllChem.UFFOptimizeMolecule(m2, confId=d)


    for c in range(cnm+1): # Cycles

        # Fake the cycles and geometries. 
         # This will allow me to use previous conformer selection scripts without the need to modify them.
        start = c * gnm
        stop = (c + 1) * gnm
#        print('start stop: ', start, stop)
        for g, i in enumerate(ids[start:stop]):
#            print('cycle geometry', c,g)
            cycle = '%04d' % (c+1)
            geom = '%02d' % (g+1)
        
            molfile = join(dirmol, f'{id_add}_{cycle}_geom{geom}.mol')
            Chem.SDWriter(molfile).write(m2, confId=i)

            # Make specific dft directory for the .xyz, which corresponds to how the directories are set up
              # for AMBER SA conformers. 
            dirxyz = join('output', 'dft', f'{id_add}', f'cycle_{cycle}_geom{geom}')
            if not exists(dirxyz):
                makedirs(dirxyz)  

            # Convert to .xyz
            mol = list(pybel.readfile('mol', molfile))
            xyzfile = join(dirxyz, f'{id_add}_{cycle}_geom{geom}.xyz')
            mol[0].write('xyz', xyzfile, True)

    print('Finished at: ', (time()-START)/60)
